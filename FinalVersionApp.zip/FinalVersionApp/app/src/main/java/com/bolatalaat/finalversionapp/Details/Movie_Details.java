package com.bolatalaat.finalversionapp.Details;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bolatalaat.finalversionapp.Adapters.ReviewAdapter;
import com.bolatalaat.finalversionapp.Adapters.TrailerAdapter;
import com.bolatalaat.finalversionapp.Entities.MovieData;
import com.bolatalaat.finalversionapp.Entities.ReviewData;
import com.bolatalaat.finalversionapp.Entities.TrailerData;
import com.bolatalaat.finalversionapp.Favourits.Favorite;
import com.bolatalaat.finalversionapp.R;
import com.linearlistview.LinearListView;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Boal on 9/23/2016.
 */
public class Movie_Details extends AppCompatActivity {

    private LinearListView mTrailersView;
    private LinearListView mReviewsView;

    private CardView mReviewsCardview;
    private CardView mTrailersCardview;
    private TrailerAdapter mTrailerAdapter;
    private ReviewAdapter mReviewAdapter;
    private TrailerData mTrailerData;
    private MovieData mMovieData;
    String title, votingNumber, releasedate, overview, imageURL, id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        TextView txt_title2 = (TextView) findViewById(R.id.txt_title2);
        TextView txt_votingNumber2 = (TextView) findViewById(R.id.txt_votingNumber2);
        ImageView img_drop = (ImageView) findViewById(R.id.img_drop2);
        TextView txt_overiew = (TextView) findViewById(R.id.txt_overview2);
        TextView txt_releasedate = (TextView) findViewById(R.id.txt_releaseDate2);


        Intent intent = getIntent();

        title = intent.getStringExtra("title");
        id = intent.getStringExtra("id");
        votingNumber = intent.getStringExtra("votingNumber");
        releasedate = intent.getStringExtra("releasedate");
        overview = intent.getStringExtra("overview");
        imageURL = intent.getStringExtra("imageURL");

        Picasso.with(this).load(imageURL).into(img_drop);
        txt_title2.setText(title);
        txt_votingNumber2.setText(votingNumber);
        txt_overiew.setText(overview);
        txt_releasedate.setText(releasedate);


        mMovieData = new MovieData(Integer.parseInt(id), title, releasedate, "", overview, "", imageURL, votingNumber);

        mTrailersView = (LinearListView) findViewById(R.id.detail_trailers);
        mReviewsView = (LinearListView) findViewById(R.id.detail_reviews);

        mReviewsCardview = (CardView) findViewById(R.id.detail_reviews_cardview);
        mTrailersCardview = (CardView) findViewById(R.id.detail_trailers_cardview);

        mTrailerAdapter = new TrailerAdapter(Movie_Details.this, new ArrayList<TrailerData>());
        mTrailersView.setAdapter(mTrailerAdapter);
        

        mTrailersView.setOnItemClickListener(new LinearListView.OnItemClickListener() {
            @Override
            public void onItemClick(LinearListView linearListView, View view,
                                    int position, long id) {
                TrailerData trailerData = mTrailerAdapter.getItem(position);
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("http://www.youtube.com/watch?v=" + trailerData.getKey()));
                startActivity(intent);
            }
        });
        mReviewAdapter = new ReviewAdapter(Movie_Details.this, new ArrayList<ReviewData>());
        mReviewsView.setAdapter(mReviewAdapter);

    }

    @Override
    public void onStart() {
        super.onStart();
        if (mMovieData != null) {
            new TrailerTask().execute(Integer.toString(mMovieData.getId()));
            new ReviewTask().execute(Integer.toString(mMovieData.getId()));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_details, menu);

        final MenuItem action_favorite = menu.findItem(R.id.action_star);

        new AsyncTask<Void, Void, Integer>() {
            @Override
            protected Integer doInBackground(Void... params) {
                return IsFavoriteMovie(mMovieData.getId());
            }

            @Override
            protected void onPostExecute(Integer isFavorited) {
                action_favorite.setIcon(isFavorited == 1 ? R.drawable.rating_star_on : R.drawable.rating_star_off);
            }
        }.execute();

        return true;

    }


    @Override
    public boolean onOptionsItemSelected(final MenuItem item) {

        int id = item.getItemId();
        switch (id) {
            case R.id.action_star:
                if (mMovieData != null) {
                    int isFavorite = IsFavoriteMovie(mMovieData.getId());
                    if ((isFavorite == 1)) {
                        Favorite.DeleteFavoriteMovieById(getApplicationContext(), mMovieData.getId());
                        item.setIcon(R.drawable.rating_star_off);
                        Toast.makeText(getApplicationContext(), R.string.removed_from_favorites, Toast.LENGTH_SHORT).show();
                    } else {
                        ArrayList<MovieData> movieDataArrayList = Favorite.loadFavorites(getApplicationContext());
                        if ((movieDataArrayList == null))
                            movieDataArrayList = new ArrayList<>();
                        movieDataArrayList.add(mMovieData);
                        Favorite.DeleteFavoriteMovies(getApplicationContext());
                        Favorite.storeFavorites(getApplicationContext(), movieDataArrayList);
                        item.setIcon(R.drawable.rating_star_on);
                        Toast.makeText(getApplicationContext(), R.string.added_to_favorites, Toast.LENGTH_SHORT).show();

                    }
                }
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public Integer IsFavoriteMovie(int id) {
        ArrayList<MovieData> movieDataArrayList = Favorite.loadFavorites(getApplicationContext());
        if ((movieDataArrayList != null)) {

            for (int i = 0; i < movieDataArrayList.size(); i++) {
                MovieData movieData = movieDataArrayList.get(i);
                if (movieData.getId() == id)
                    return 1;
            }
            return 0;
        } else
            return 0;
    }

    public class TrailerTask extends AsyncTask<String, Void, List<TrailerData>> {

        private final String LOG_TAG = TrailerTask.class.getSimpleName();

        private List<TrailerData> getTrailersDataFromJson(String jsonStr) throws JSONException {
            JSONObject trailerJson = new JSONObject(jsonStr);
            JSONArray trailerArray = trailerJson.getJSONArray("results");

            List<TrailerData> results = new ArrayList<>();

            for (int i = 0; i < trailerArray.length(); i++) {
                JSONObject trailer = trailerArray.getJSONObject(i);
                if (trailer.getString("site").contentEquals("YouTube")) {
                    TrailerData trailerDataModel = new TrailerData(trailer);
                    results.add(trailerDataModel);
                }
            }

            return results;
        }

        @Override
        protected List<TrailerData> doInBackground(String... params) {

            if (params.length == 0) {
                return null;
            }

            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;

            String jsonStr = null;

            try {
                final String BASE_URL = "http://api.themoviedb.org/3/movie/" + params[0] + "/videos";
                final String API_KEY_PARAM = "api_key";

                Uri builtUri = Uri.parse(BASE_URL).buildUpon()
                        .appendQueryParameter(API_KEY_PARAM, getString(R.string.app_api))
                        .build();

                URL url = new URL(builtUri.toString());

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {

                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    return null;
                }
                jsonStr = buffer.toString();
            } catch (IOException e) {
                Log.e(LOG_TAG, "Error ", e);
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e(LOG_TAG, "Error closing stream", e);
                    }
                }
            }

            try {
                return getTrailersDataFromJson(jsonStr);
            } catch (JSONException e) {
                Log.e(LOG_TAG, e.getMessage(), e);
                e.printStackTrace();
            }

            return null;
        }

        @Override

        protected void onPostExecute(List<TrailerData> trailerDatas) {
            if (trailerDatas != null) {
                if (trailerDatas.size() > 0) {
                    mTrailersCardview.setVisibility(View.VISIBLE);
                    if (mTrailerAdapter != null) {
                        mTrailerAdapter.clear();
                        for (TrailerData trailerData : trailerDatas) {
                            mTrailerAdapter.add(trailerData);
                        }
                    }


                }
            }
        }
    }



    public class ReviewTask extends AsyncTask<String, Void, List<ReviewData>> {

        private final String LOG_TAG = ReviewTask.class.getSimpleName();

        private List<ReviewData> getReviewsDataFromJson(String jsonStr) throws JSONException {
            JSONObject reviewJson = new JSONObject(jsonStr);
            JSONArray reviewArray = reviewJson.getJSONArray("results");

            List<ReviewData> results = new ArrayList<>();

            for (int i = 0; i < reviewArray.length(); i++) {
                JSONObject review = reviewArray.getJSONObject(i);
                results.add(new ReviewData(review));
            }

            return results;
        }

        @Override
        protected List<ReviewData> doInBackground(String... params) {

            if (params.length == 0) {
                return null;
            }

            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;

            String jsonStr = null;

            try {
                final String BASE_URL = "http://api.themoviedb.org/3/movie/" + params[0] + "/reviews";
                final String API_KEY_PARAM = "api_key";

                Uri builtUri = Uri.parse(BASE_URL).buildUpon()
                        .appendQueryParameter(API_KEY_PARAM, getString(R.string.app_api))
                        .build();

                URL url = new URL(builtUri.toString());

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {

                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    return null;
                }
                jsonStr = buffer.toString();
            } catch (IOException e) {
                Log.e(LOG_TAG, "Error ", e);
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e(LOG_TAG, "Error closing stream", e);
                    }
                }
            }

            try {
                return getReviewsDataFromJson(jsonStr);
            } catch (JSONException e) {
                Log.e(LOG_TAG, e.getMessage(), e);
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(List<ReviewData> reviewDatas) {
            if (reviewDatas != null) {
                if (reviewDatas.size() > 0) {
                    mReviewsCardview.setVisibility(View.VISIBLE);
                    if (mReviewAdapter != null) {
                        mReviewAdapter.clear();
                        for (ReviewData reviewData : reviewDatas) {
                            mReviewAdapter.add(reviewData);
                        }
                    }
                }
            }
        }
    }


}
