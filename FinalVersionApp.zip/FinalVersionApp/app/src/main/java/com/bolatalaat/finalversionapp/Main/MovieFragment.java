package com.bolatalaat.finalversionapp.Main;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import com.bolatalaat.finalversionapp.Adapters.GridViewAdapter;
import com.bolatalaat.finalversionapp.Details.Movie_Details;
import com.bolatalaat.finalversionapp.Entities.MovieData;
import com.bolatalaat.finalversionapp.Favourits.Favorite;
import com.bolatalaat.finalversionapp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Bola on 9/21/2016.
 */
public class MovieFragment extends Fragment {
    
    GridView gridView;

    GridViewAdapter gridViewAdapter;
    private static final String POPULARITY = "popularity.desc";
    private static final String RATING = "vote_count.desc";
    private static final String FAVORITE = "favorite";


    private String SortedBy = POPULARITY;

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu, menu);
        MenuItem action_sort_by_popularity = menu.findItem(R.id.action_sort_by_popularity);
        MenuItem action_sort_by_rating = menu.findItem(R.id.action_sort_by_rating);
        MenuItem action_sort_by_favorite = menu.findItem(R.id.action_sort_by_favorite);

        if (SortedBy.contentEquals(POPULARITY)) {
            if (!action_sort_by_popularity.isChecked()) {
                action_sort_by_popularity.setChecked(true);
            }
        } else if (SortedBy.contentEquals(RATING)) {
            if (!action_sort_by_rating.isChecked()) {
                action_sort_by_rating.setChecked(true);
            }
        } else if (SortedBy.contentEquals(FAVORITE)) {
            if (!action_sort_by_popularity.isChecked()) {
                action_sort_by_favorite.setChecked(true);
            }
        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.action_sort_by_popularity:
                if (item.isChecked()) {
                    item.setChecked(false);
                } else {
                    item.setChecked(true);
                }
                SortedBy = POPULARITY;
                updateMovies(SortedBy);
                return true;
            case R.id.action_sort_by_rating:
                if (item.isChecked()) {
                    item.setChecked(false);
                } else {
                    item.setChecked(true);
                }
                SortedBy = RATING;
                updateMovies(SortedBy);
                return true;
            case R.id.action_sort_by_favorite:
                if (item.isChecked()) {
                    item.setChecked(false);
                } else {
                    item.setChecked(true);
                }
                SortedBy = FAVORITE;
                updateMovies(SortedBy);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    
    
    private void updateMovies(String sort_by) {
        if (!sort_by.contentEquals(FAVORITE)) {
            new MovieTask(getActivity()).execute(sort_by);
        }
        else {
            gridViewAdapter = new GridViewAdapter(getActivity(), Favorite.loadFavorites(getActivity()));
            gridView.setAdapter(gridViewAdapter);
            gridViewAdapter.notifyDataSetChanged();
        }
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.main_fragement, container);
        gridView = (GridView) root.findViewById(R.id.gridview_movies);

            MovieTask movieTask = new MovieTask(getActivity());
            movieTask.execute();

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                TextView txt_title = (TextView) view.findViewById(R.id.txt_title);
                TextView txt_language = (TextView) view.findViewById(R.id.txt_Language);
                TextView txt_votingNumber = (TextView) view.findViewById(R.id.txt_votingNumber);
                TextView txt_overview = (TextView) view.findViewById(R.id.txt_overview);
                TextView txt_releaseDate = (TextView) view.findViewById(R.id.txt_releaseDate);
                TextView txt_votingcount = (TextView) view.findViewById(R.id.txt_votecount);
                TextView txt_imageURL = (TextView) view.findViewById(R.id.txt_imageURL);
                TextView txt_id = (TextView) view.findViewById(R.id.txt_id);

                Intent intent = new Intent(getActivity(), Movie_Details.class);

                intent.putExtra("id", txt_id.getText());
                intent.putExtra("title", txt_title.getText());
                intent.putExtra("imageURL", txt_imageURL.getText());
                intent.putExtra("language", txt_language.getText());
                intent.putExtra("votingNumber", txt_votingNumber.getText());
                intent.putExtra("overview", txt_overview.getText());
                intent.putExtra("releasedate", txt_releaseDate.getText());
                intent.putExtra("votecount", txt_votingcount.getText());

                startActivity(intent);

            }
        });
        return  root;
    }


    public void onFinishDataLoading(ArrayList<MovieData> movies) {

        gridViewAdapter = new GridViewAdapter(getActivity(), movies);
        gridView.setAdapter(gridViewAdapter);
        gridViewAdapter.notifyDataSetChanged();

    }

    public  class MovieTask extends AsyncTask<String, Void, ArrayList<MovieData>> {
//        private final String LOG_TAG = MovieTask.class.getSimpleName();
        private final String LOG_TAG ="BOLA";
        private Context context;

        public MovieTask(Context context) {
            this.context = context;
        }

        private ArrayList<MovieData> getMoviesDataFromJson(String jsonStr) throws JSONException {
            JSONObject movieJson = new JSONObject(jsonStr);
            JSONArray movieArray = movieJson.getJSONArray("results");

            ArrayList<MovieData> results = new ArrayList<>();

            for (int i = 0; i < movieArray.length(); i++) {
                JSONObject movie = movieArray.getJSONObject(i);
                MovieData movieDataModel = new MovieData(movie);
                results.add(movieDataModel);
            }

            return results;
        }


        @Override
        protected ArrayList<MovieData> doInBackground(String... params) {

//           String moviesURL = params[0];
            if (params.length == 0) {
                return null;
            }
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;

            String jsonStr = null;

            try {
                final String BASE_URL = "http://api.themoviedb.org/3/discover/movie?";
                final String SORT_BY_PARAM = "sort_by";
                final String API_KEY_PARAM = "api_key";

                Uri builtUri = Uri.parse(BASE_URL).buildUpon()
                        .appendQueryParameter(SORT_BY_PARAM, params[0])
                        .appendQueryParameter(API_KEY_PARAM, getString(R.string.app_api))
                        .build();

                URL url = new URL(builtUri.toString());

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {

                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    return null;
                }
                jsonStr = buffer.toString();
            } catch (IOException e) {
                Log.e(LOG_TAG, "Error ", e);
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e(LOG_TAG, "Error closing stream", e);
                    }
                }
            }

            try {
                return getMoviesDataFromJson(jsonStr);
            } catch (JSONException e) {
                Log.e(LOG_TAG, e.getMessage(), e);
                e.printStackTrace();
            }


            return null;


        }

        @Override
        protected void onPostExecute(ArrayList<MovieData> movies) {
            if (movies != null) {

                onFinishDataLoading(movies);
            }
        }

    }
}
