package com.bolatalaat.finalversionapp.Entities;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Bola on 9/21/2016.
 */
public class ReviewData {
    private String id;
    private String author;
    private String content;

    public ReviewData() {

    }

    public ReviewData(JSONObject trailer) throws JSONException {
        this.id = trailer.getString("id");
        this.author = trailer.getString("author");
        this.content = trailer.getString("content");
    }

    public String getId() { return id; }

    public String getAuthor() { return author; }

    public String getContent() { return content; }

}
