package com.bolatalaat.finalversionapp.Entities;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Bola on 9/21/2016.
 */
public class TrailerData {

    private String id;
    private String key;
    private String name;


    public TrailerData() {

    }

    public TrailerData(JSONObject trailer) throws JSONException {
        this.id = trailer.getString("id");
        this.key = trailer.getString("key");
        this.name = trailer.getString("name");

    }

    public String getId() {
        return id;
    }

    public String getKey() { return key; }

    public String getName() { return name; }

}
